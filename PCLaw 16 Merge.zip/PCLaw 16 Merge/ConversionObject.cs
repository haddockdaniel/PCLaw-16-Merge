﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCLaw_16_Merge
{
    public class ConversionObject
    {
        public string method { get; set; }
        public int order { get; set; }
        public bool runMethod { get; set; }
    }
}
